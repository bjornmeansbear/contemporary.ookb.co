# The Contemporary

Contained here are ideas, forms, code, etc. by the Office of Kristian Bjornard for The Contemporary.
webpages actually live on the gh-pages branch.