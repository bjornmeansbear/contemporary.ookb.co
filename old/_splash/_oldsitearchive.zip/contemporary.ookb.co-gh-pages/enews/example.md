Example Mailchimp code:
http://us5.campaign-archive1.com/?u=a43cf3ad71&id=1fd3199481&e=18d5167a9f

http://us1.campaign-archive1.com/?u=2211e480c74629730b9896d4e&id=cf4e503154&e=5de33447fe